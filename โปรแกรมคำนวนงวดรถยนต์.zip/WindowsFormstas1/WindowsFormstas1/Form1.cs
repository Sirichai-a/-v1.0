﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormstas1
{
    public partial class Form1 : Form
    {
        DataTable data = new DataTable();   //กำหนด data
        int primiry = 0;                    //กำหนดตัวแปล primiry 
        public Form1()
        {
            InitializeComponent();

            DataColumn col6 = new DataColumn();    //กำหนด column
            DataColumn col1 = new DataColumn();
            DataColumn col2 = new DataColumn();
            DataColumn col3 = new DataColumn();
            DataColumn col4 = new DataColumn();
            DataColumn col5 = new DataColumn();


            col6.ColumnName = "ลำดับ";                    //กำหนด col6 = ใน ""
            col1.ColumnName = "ราคารถยนต์";               //กำหนด col1 = ใน ""
            col2.ColumnName = "เงินดาวน์";                 //กำหนด col2 = ใน ""    
            col3.ColumnName = "ดอกเบี้ยเปอร์เซ็นซ์ต่อปี";        //กำหนด col3 = ใน ""  
            col4.ColumnName = "ยอดจัดไฟแนนซ์";            //กำหนด col4 = ใน ""
            col5.ColumnName = "ราคางวดต่อเดือน";           //กำหนด col5 = ใน ""

            data.Columns.Add(col6);                     //กำหนดแถวลานนอน
            data.Columns.Add(col1);
            data.Columns.Add(col2);
            data.Columns.Add(col3);
            data.Columns.Add(col4);
            data.Columns.Add(col5);

            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            primiry++;          //เมื่อกดปุ่ม button1 จะบวกไปทีละ 1 โดยเริ่มจาก 0
            try                 //ดัก error
            {
               

                    double y1, y2, y3, y4, y5, y6;      //กำหนดตัวแปล      

                    double car, dow, dok, fin, a;       //กำหนดตัวแปล


                    car = double.Parse(textBox1.Text);      //car = ราคารถยนต์
                    dow = double.Parse(textBox2.Text);      //dow = เงินดาว
                    fin = car - dow;                        //fin = ยอดจัดไฟแนนนซ์

                    dok = double.Parse(textBox3.Text);
                    a = (fin * dok) / 100;                  // a = สูตรในการคิดดอกเบี้ย

  

                    y1 = a * 1;                 // y1 -> y6 = สูตรในการรับค่า 
                    y2 = a * 2;
                    y3 = a * 3;
                    y4 = a * 4;
                    y5 = a * 5;
                    y6 = a * 6;

                double z1, z2, z3, z4, z5, z6;  // z1 -> z6 = สูตรการรับค่า

                    z1 = fin + y1;
                    z2 = fin + y2;
                    z3 = fin + y3;
                    z4 = fin + y4;
                    z5 = fin + y5;
                    z6 = fin + y6;


                double n1, n2, n3, n4, n5, n6;  // n = end คือราคาที่ต้องจ่ายต่อเดือน

                    n1 = z1 / 12;
                    n2 = z2 / 24;
                    n3 = z3 / 36;
                    n4 = z4 / 48;
                    n5 = z5 / 60;
                    n6 = z6 / 72;

                 //=================================================================

                    DataRow newRow = data.NewRow();
                    DataRow newRow2 = data.NewRow();
                    DataRow newRow3 = data.NewRow();
                    DataRow newRow4 = data.NewRow();
                    DataRow newRow5 = data.NewRow();

              
                    newRow["ลำดับ"] = Convert.ToString(primiry);        //แสดง ลำดับ
                    newRow["ราคารถยนต์"] = this.textBox1.Text;           //แสดง ราคารถยนต์
                    newRow["เงินดาวน์"] = this.textBox2.Text;             //แสดง เงินดาวน์
                    newRow["ดอกเบี้ยเปอร์เซ็นซ์ต่อปี"] = this.textBox3.Text;    //แสดง ดอกเบี้ยเปอร์เซ็นซ์ต่อปี
                    newRow["ยอดจัดไฟแนนซ์"] = fin.ToString("#,##");      //แสดง ยอดจัดไฟแนนซ์
                    newRow["ราคางวดต่อเดือน"] = "12 งวด (1ปี)" + n1.ToString("#,##"); data.Rows.Add(newRow); this.dataGridView1.DataSource = data; //แสดง nๅ = ราคางวดต่อเดือน


                newRow2["ราคางวดต่อเดือน"] = "24 งวด (2ปี)" + n2.ToString("#,##"); data.Rows.Add(newRow2); this.dataGridView1.DataSource = data;   //แสดง n2 = ราคางวดต่อเดือน
                newRow3["ราคางวดต่อเดือน"] = "36 งวด (3ปี)" + n3.ToString("#,##"); data.Rows.Add(newRow3); this.dataGridView1.DataSource = data;   //แสดง n3 = ราคางวดต่อเดือน
                newRow4["ราคางวดต่อเดือน"] = "48 งวด (4ปี)" + n4.ToString("#,##"); data.Rows.Add(newRow4); this.dataGridView1.DataSource = data;   //แสดง n4 = ราคางวดต่อเดือน
                newRow5["ราคางวดต่อเดือน"] = "60 งวด (5ปี)" + n5.ToString("#,##"); data.Rows.Add(newRow5); this.dataGridView1.DataSource = data;   //แสดง n5 = ราคางวดต่อเดือน


                //===================================================================================

            }
            catch      //ดัก error
            { 
                if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")  //กำหนดเงื่อนไข
                {
                    MessageBox.Show("กรุณากรอกข้อมูลให้ครบถ้วน");     //แสดงเมื่อเงื่อนไขเป็น จริง
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();                  //คำสั่งเคลียร์ textBox
            textBox2.Clear();
            textBox3.Clear();
            dataGridView1.Columns.Clear();     //คำสั่งเคลียร์ dataGridView
        }
    }

}

        
  
